su -c "amixer get 'Mic'"
