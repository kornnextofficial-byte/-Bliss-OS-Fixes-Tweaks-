su -c "amixer sset 'Mic' 0dB"
