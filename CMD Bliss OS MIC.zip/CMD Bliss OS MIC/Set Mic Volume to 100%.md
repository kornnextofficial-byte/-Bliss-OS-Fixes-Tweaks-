# Set Mic Volume to 100%

Run this command in Termux or Terminal with Root access:

```bash
su -c "amixer sset 'Mic' 100%"

su
   alsamixer
   