#Plug in your Bliss OS Live USB and boot the computer using the USB drive.
#Select Run Bliss OS without installation (Live Mode) to enter the temporary system.
#Open the Open Shell (or Terminal) app and run the following commands

mount /dev/sda1 /mnt/efi
mkdir -p /mnt/efi/EFI/BOOT
cp /mnt/efi/EFI/BlissOS/grubx64.efi /mnt/efi/EFI/BOOT/bootx64.efi
sync
exit
